For every candidate, we can fix an agenda for that candidate to win in [[Linear Sequential Pairwise Elections]]:

Suppose:
33 [[Voters]] have [[Preferences]]:
$\omega_1 ≻ \omega_2 ≻ \omega_3$ 
33 [[Voters]] have [[Preferences]]:
$\omega_3 ≻ \omega_1 ≻ \omega_1$ 
33 [[Voters]] have [[Preferences]]:
$\omega_2 ≻ \omega_3 ≻ \omega_1$ 

$\omega_1$ wins with agenda:
$$
\omega_2,\omega_3,\omega_1 \rightarrow \omega_2,\omega_1 \rightarrow \omega_1
$$
$\omega_2$ wins with agenda:
$$
\omega_3,\omega_1,\omega_2 \rightarrow \omega_3,\omega_2 \rightarrow \omega_2
$$
$\omega_3$ wins with agenda:
$$
\omega_1,\omega_2,\omega_3 \rightarrow \omega_1,\omega_3 \rightarrow \omega_3
$$


You can illustrate this idea by using a [[Majority Graph]] 