It states that no voting system can perfectly translate individual [[Preferences]] into a collective decision while meeting a set of fair and desirable criteria.

The only voting procedure that satisfies both [[The Pareto Property]] and [[Independence of Irrelevant Alternatives (IIA)]] is a dictatorship. (Outcome is selected by one of the voters)

Therefore there are fundamental limits to democratic decision making!

