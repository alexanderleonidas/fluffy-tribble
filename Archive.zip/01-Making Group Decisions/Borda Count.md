The Borda count is a [[Social Welfare Functions|social welfare function]] that takes the whole [[Preferences|preference order]] into account.

Each [[Candidates|candidate]] is being described by a variable, which counts the strength of opinion of this candidate.

For each [[Preferences|preference order]] and [[Candidates|candidates]] $\omega_i$: 
If $\omega_i$ appears first in the preference order, increment the count for $\omega_i$ by $k -1$, where $k$ is the number of candidates. Then increment the count for the next candidate by $k-2$. Repeat this until the final candidate in the preference order has its counts incremented by 0=($k-k$).

After doing this for all [[Voters]], the totals give the ranking of each candidate.

