A set $\Omega=\{ \omega _1, \omega _2, ... \}$ of outcomes.

For $|\Omega|=2$ its called a [[Pairwise Election]]. 