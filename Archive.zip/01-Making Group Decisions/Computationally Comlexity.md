[[The Gibbard-Satterthwaite Theorem]] only tells us that [[Strategic Manipulation]] is possible in principle. It does not give any indication of how to misrepresent [[Preferences]].

Bartholdi, Tovey, and Trick showed that there are elections that are prone to manipulation in principle, but where the manipulation was computationally complex.

