A Condorcet Winner is a [[Candidates|candidate]] that would beat every other in a [[Majority Graph|pairwise election]]. 

Here, $\omega_1$ is a Condorcet Winner:
![[Majority-Graph-Example03.png]]

$\omega_1,\omega_2  \rightarrow \omega_1$ wins
$\omega_1,\omega_3  \rightarrow \omega_1$ wins
$\omega_1,\omega_4  \rightarrow \omega_1$ wins

## Condorcet Losers
Opposite of Condorcet Winner, would always lose pairwise.
$\omega_4$ is the above example.
