There are situations in which, no matter which [[Candidates|candidate]] we choose, a majority of [[Voters|voters]] will be unhappy with the outcome chosen.

Let $|Ag|=\{1,2,3\}$ and $\Omega = \{ \omega _1, \omega _2, \omega_3 \}$ with:
$\omega_1 ≻_1 \omega_2 ≻_1 \omega_3$ 
$\omega_3 ≻_2 \omega_1 ≻_2 \omega_2$
$\omega_2 ≻_3 \omega_3 ≻_3 \omega_1$ 

For every possible [[Candidates|candidate]], there is another that is preferred by a majority of [[Voters|voters]].