There are two properties to classify a voting procedure as "good":

- [[The Pareto Property]]
- [[Independence of Irrelevant Alternatives (IIA)]]