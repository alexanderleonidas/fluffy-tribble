Whether $\omega_i$ is ranked above $\omega_j$ in the social outcome should depend only on the relative orderings of $\omega_i$ and $\omega_j$ in [[Voters]] profiles.

The ranking of two options should not change due to the introduction or removal of other alternatives.

Example:
Imagine a voting scenario where there are three candidates: A, B, and C. 
According to IIA:
- If voters prefer A over B when only A and B are considered, the introduction of candidate C should not change this preference.
- So, if voters still prefer A over B when all three candidates are considered (A, B, and C), the addition of C shouldn't change that preference.