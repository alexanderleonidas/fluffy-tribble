# Intelligent Systems - Agent and Multiagent Technology  
**Part 1**  
*Gerhard Weiss, DACS, Maastricht University*  

---
## Motivation  
### Artificial Intelligence at a Glance  
- **Core Challenge**: No universally accepted definition of "intelligence."  
  - Subtypes: Social, emotional, senso-motoric, mental.  
  - **AI’s Indirect Goal**: Computational precision of human-like intelligence.  
  - **AI as a Field**: Multidisciplinary, focusing on systems that exhibit intelligent behavior (e.g., reasoning, learning, adaptation).  

#### Turing Test and AI Paradigms  
- Proposed by Alan Turing (1950): A machine is intelligent if its written responses are indistinguishable from a human’s.  
- **Weak AI**: Mimics intelligence (e.g., IBM’s Deep Blue for chess).  
- **Strong AI**: Possesses consciousness and genuine thought (still theoretical).  
- **Pragmatic vs. Visionary Goals**:  
  - *Pragmatic*: Achieve functional equivalence to human intelligence.  
  - *Visionary*: Replicate the mechanisms of human/animal cognition.  

#### Key Themes in AI  
- **Knowledge Representation**: Structuring information for reasoning (e.g., semantic networks).  
- **Natural Language Processing**: Understanding/generating human language (e.g., chatbots).  
- **Robotics**: Combining perception, planning, and physical action (e.g., autonomous drones).  
- **Expert Systems**: Domain-specific problem-solving (e.g., medical diagnosis tools like MYCIN).  

---

### AI Perspectives  
#### 1. Knowledge-Based AI  
- **Guiding Principle**: Intelligence = Knowledge + Symbolic Reasoning.  
  - **Symbol System Hypothesis** (Newell & Simon): Symbol manipulation is necessary/sufficient for intelligence.  
  - **Top-Down Design**: Start with high-level concepts (e.g., logic-based systems like Prolog).  
  - **Critique**: Overlooks real-world interaction (e.g., a chess program knows rules but lacks "understanding").  

#### 2. Behavior-Based AI  
- **Guiding Principle**: Intelligence emerges from simple behaviors (e.g., Brooks’ subsumption architecture).  
  - **Physical Grounding Hypothesis**: Symbols must connect to real-world sensors/effectors (e.g., a robot avoiding walls).  
  - **Bottom-Up Design**: Build intelligence incrementally (e.g., Roomba’s obstacle avoidance).  

#### 3. Connectionism (Neural Networks)  
- **Guiding Principle**: Mimic brain-like parallel processing.  
  - **Artificial Neural Networks (ANNs)**: Layers of interconnected nodes (e.g., image recognition with CNNs).  
  - **Subsymbolic Processing**: Learning patterns without explicit rules (e.g., GPT-3 for text generation).  

#### 4. Distributed AI (DAI)  
- **Guiding Principle**: Intelligence through collaboration (e.g., [[#The Multi-Agent Concept]]).  
  - **Key Features**:  
    - Decentralized control (e.g., swarm robotics).  
    - Coordination mechanisms (e.g., auction-based task allocation).  
  - **Why DAI?**: Scalability, robustness, and natural modeling of social systems.  

---

## Agent Orientation  
### The Agent Concept  
**Definition**:  
> A computational entity situated in an environment, capable of **autonomous, flexible action** (reactivity + proactivity) to achieve goals.  

#### Core Characteristics  
1. **Situatedness**: Operates within a dynamic environment (e.g., a drone in a warehouse).  
2. **Autonomy**: Decides *when* and *how* to act (e.g., a trading bot executing orders without human input).  
3. **Flexibility**:  
   - *Reactivity*: Responds to changes (e.g., adjusting route due to traffic).  
   - *Proactivity*: Pursues goals proactively (e.g., a personal assistant scheduling meetings).  

#### Agents vs. Objects: A Deeper Dive  
| Aspect          | Objects                                  | Agents                                   |  
|-----------------|------------------------------------------|------------------------------------------|  
| **Invocation**  | Methods called externally (passive).     | Self-invoked actions (active).           |  
| **State**       | Encapsulates data (e.g., variables).     | Encapsulates *goals* and *beliefs*.      |  
| **Interaction** | Message-passing (e.g., Java method calls). | High-level communication (e.g., FIPA ACL). |  

#### Evolution of Programming Paradigms  
- **Monolithic → Modular → OO → Agent-Oriented (AO)**:  
  - Increasing encapsulation (e.g., agents hide decision-making logic).  
  - Shift from *control flow* (procedural) to *goal-driven* autonomy.  
- **Example**:  
  - *Monolithic*: A single script controlling a factory.  
  - *AO*: Autonomous machines negotiating production schedules.  

---

## Applications from an Agent-Oriented Perspective  
### Case Studies  
1. **Automated Production Systems**  
   - **Agents**: Machines, robots, conveyor belts.  
   - **Interaction**: Negotiating task priorities (e.g., coordination via contract net protocol).  
   - **Flexibility**: Dynamic rescheduling if a machine fails.  

2. **Traffic Flow Regulation**  
   - **Agents**: Traffic lights, vehicles, sensors.  
   - **Autonomy**: Lights adjust timings based on real-time congestion.  
   - **Proactivity**: Predictive rerouting using historical data.  

3. **Supply Chain Management**  
   - **Agents**: Suppliers, warehouses, logistics providers.  
   - **Cooperation**: Collaborative demand forecasting (e.g., sharing inventory data).  
   - **Resilience**: Handling disruptions (e.g., a supplier delay) via decentralized decisions.  

4. **Personal Software Assistants**  
   - **Agents**: Calendar bots, email filters.  
   - **Proactivity**: Scheduling meetings by analyzing priorities.  
   - **Adaptivity**: Learning user preferences over time (e.g., prioritizing certain contacts).  

### When to Use Agent-Oriented Design?  
- **Ideal For**:  
  - Open, dynamic environments (e.g., IoT networks).  
  - Systems with decentralized control (e.g., peer-to-peer energy grids).  
  - Applications requiring adaptive behavior (e.g., disaster response robots).  

---

## Agent-Oriented Engineering  
### Benefits  
- **Parallelism**: Concurrent task execution (e.g., drone swarms mapping a forest).  
- **Robustness**: No single point of failure (e.g., a failed agent is replaced by peers).  
- **Scalability**: Adding agents without redesigning the system (e.g., expanding a delivery fleet).  

### Pitfalls  
- **Overselling Agents**: Not every system needs agents (e.g., a static database).  
- **Buzzword Trap**: "Agent" ≠ "AI" – clarify requirements first.  
- **Integration Challenges**: Legacy systems may resist decentralized control.  

### Design Levels  
1. **Intra-Agent**:  
   - Internal logic (e.g., BDI architecture: **B**eliefs, **D**esires, **I**ntentions).  
   - Learning mechanisms (e.g., reinforcement learning for decision-making).  

2. **Inter-Agent**:  
   - Communication protocols (e.g., HTTP, FIPA ACL).  
   - Coordination strategies (e.g., auctions, voting).  

3. **Supra-Agent**:  
   - Organizational structures (e.g., hierarchical, market-based).  
   - Social norms (e.g., rules for conflict resolution).  

---

## The Multi-Agent Concept  
### Core Idea  
> A system of multiple agents interacting to achieve individual or shared goals.  

#### Key Features  
- **Distributed Sensing/Acting**: Agents operate in parallel (e.g., sensor networks monitoring pollution).  
- **Emergent Behavior**: Global outcomes from local interactions (e.g., flocking birds in simulation).  

### Forms of Interaction  
1. **Coordination**: Aligning actions without shared goals (e.g., traffic lights synchronizing).  
2. **Collaboration**: Working toward a common goal (e.g., robots assembling furniture).  
3. **Competition**: Conflicting objectives (e.g., auction-based resource allocation).  

#### Example: Predator-Prey Games  
- **Agents**: Predators (hunters) and prey (targets).  
- **Interaction**: Competitive (predators coordinate to corner prey).  
- **Autonomy**: Prey agents evade using real-time environment data.  

---

## Concluding Remarks  
Agent-oriented systems excel in **complex, dynamic domains** where decentralization and adaptability are critical. Success hinges on balancing agent autonomy with effective interaction protocols, while avoiding over-engineering.  