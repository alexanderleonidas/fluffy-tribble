## Anomalies with Sequential Pairwise Elections
For every candidate, we can fix an agenda for that candidate to win in [[#Linear Sequential Pairwise Elections]]:

Suppose:
33 [[#Voters]] have [[#Preferences]]:
$\omega_1 ≻ \omega_2 ≻ \omega_3$ 
33 [[#Voters]] have [[#Preferences]]:
$\omega_3 ≻ \omega_1 ≻ \omega_1$ 
33 [[#Voters]] have [[#Preferences]]:
$\omega_2 ≻ \omega_3 ≻ \omega_1$ 

$\omega_1$ wins with agenda:
$$
\omega_2,\omega_3,\omega_1 \rightarrow \omega_2,\omega_1 \rightarrow \omega_1
$$
$\omega_2$ wins with agenda:
$$
\omega_3,\omega_1,\omega_2 \rightarrow \omega_3,\omega_2 \rightarrow \omega_2
$$
$\omega_3$ wins with agenda:
$$
\omega_1,\omega_2,\omega_3 \rightarrow \omega_1,\omega_3 \rightarrow \omega_3
$$


You can illustrate this idea by using a [[#Majority Graph]] 
## Arrow's Theorem
It states that no voting system can perfectly translate individual [[#Preferences]] into a collective decision while meeting a set of fair and desirable criteria.

The only voting procedure that satisfies both [[#The Pareto Property]] and [[#Independence of Irrelevant Alternatives (IIA)]] is a dictatorship. (Outcome is selected by one of the voters)

Therefore there are fundamental limits to democratic decision making!


## Borda Count
The Borda count is a [[#Social Welfare Functions|social welfare function]] that takes the whole [[#Preferences|preference order]] into account.

Each [[#Candidates|candidate]] is being described by a variable, which counts the strength of opinion of this candidate.

For each [[#Preferences|preference order]] and [[#Candidates|candidates]] $\omega_i$: 
If $\omega_i$ appears first in the preference order, increment the count for $\omega_i$ by $k -1$, where $k$ is the number of candidates. Then increment the count for the next candidate by $k-2$. Repeat this until the final candidate in the preference order has its counts incremented by 0=($k-k$).

After doing this for all [[#Voters]], the totals give the ranking of each candidate.


## Candidates
A set $\Omega=\{ \omega _1, \omega _2, ... \}$ of outcomes.

For $|\Omega|=2$ its called a [[#Pairwise Election]]. 
## Computationally Comlexity
[[#The Gibbard-Satterthwaite Theorem]] only tells us that [[#Strategic Manipulation]] is possible in principle. It does not give any indication of how to misrepresent [[#Preferences]].

Bartholdi, Tovey, and Trick showed that there are elections that are prone to manipulation in principle, but where the manipulation was computationally complex.


## Condorcet Winners
A Condorcet Winner is a [[#Candidates|candidate]] that would beat every other in a [[#Majority Graph|pairwise election]]. 

Here, $\omega_1$ is a Condorcet Winner:
![[Majority-Graph-Example03.png]]

$\omega_1,\omega_2  \rightarrow \omega_1$ wins
$\omega_1,\omega_3  \rightarrow \omega_1$ wins
$\omega_1,\omega_4  \rightarrow \omega_1$ wins

## Condorcet's Paradox
There are situations in which, no matter which [[#Candidates|candidate]] we choose, a majority of [[#Voters|voters]] will be unhappy with the outcome chosen.

Let $|Ag|=\{1,2,3\}$ and $\Omega = \{ \omega _1, \omega _2, \omega_3 \}$ with:
$\omega_1 ≻_1 \omega_2 ≻_1 \omega_3$ 
$\omega_3 ≻_2 \omega_1 ≻_2 \omega_2$
$\omega_2 ≻_3 \omega_3 ≻_3 \omega_1$ 

For every possible [[#Candidates|candidate]], there is another that is preferred by a majority of [[#Voters|voters]].
## Desirable Properties of Voting Procedures
There are two properties to classify a voting procedure as "good":

- [[#The Pareto Property]]
- [[#Independence of Irrelevant Alternatives (IIA)]]
## Independence of Irrelevant Alternatives (IIA)
Whether $\omega_i$ is ranked above $\omega_j$ in the social outcome should depend only on the relative orderings of $\omega_i$ and $\omega_j$ in [[#Voters]] profiles.

The ranking of two options should not change due to the introduction or removal of other alternatives.

Example:
Imagine a voting scenario where there are three candidates: A, B, and C. 
According to IIA:
- If voters prefer A over B when only A and B are considered, the introduction of candidate C should not change this preference.
- So, if voters still prefer A over B when all three candidates are considered (A, B, and C), the addition of C shouldn't change that preference.
## Linear Sequential Pairwise Elections
A variant of [[#Sequential Majority Elections]], in which the [[#Candidates]] play in a series of linear rounds:

![[Linear-Sq-Pairwise-Elec.png]]  

There has to be an ordering of the [[#candidates]] - the **agenda** - which determines who plays against who.

The agenda seen in the example above is:
$\omega_2, \omega_3, \omega_4, \omega_1$ 

The first election is between $\omega_2$ and $\omega_3$, and the winner($\omega_2$) goes on to an election with $\omega_4$ and the winner of this election($\omega_4$) goes in an election with $\omega_1$. 

It can also be depicted like this:
$\omega_2, \omega_3, \omega_4, \omega_1 \rightarrow \omega_2, \omega_4, \omega_1 \rightarrow \omega_4, \omega_1 \rightarrow \omega_1$ wins

There are also [[#Anomalies with Sequential Pairwise Elections|Anomalies with the sequential pairwise elections]], by fixing an agenda that leads a [[#Candidates|candidate]] to win.
## Majority Graph
A direct graph where:
- vertices = [[#Candidates]]
- an edge $(i,j)$ if $i$ would beat $j$ in a [[#Plurality|simple majority election]].

For the example in [[#Anomalies with Sequential Pairwise Elections]] the Majority Graph would look like this:

 ![[Majority-Graph-Example01.png]]

Another example of a majority graph with 4 [[#Candidates]]:

![[Majority-Graph-Example02.png]]

In this example the candidates would win with the following [[#Linear Sequential Pairwise Elections|agendas]]:
$\omega_4, \omega_2, \omega_3, \omega_1 \rightarrow \omega_1$ wins 
$\omega_4,\omega_3,\omega_1,\omega_2 \rightarrow \omega_2$ wins
$\omega_2,\omega_1,\omega_4,\omega_3 \rightarrow \omega_3$ wins
$\omega_3,\omega_4,\omega_1,\omega_2 \rightarrow \omega_2$ wins

## Pairwise Election
If there are only two [[#Candidates]], we have a pairwise election.
$|\Omega|=2$ -> pairwise election

## Plurality
Plurality is a [[#Social Choice Functions|social choice function]] and therefore selects a single outcome.

The [[#Voters]] submit their [[#Preferences]] and each [[#Candidates|Candidate]] gets one point for every [[#Preferences|preference order]] that ranks them first.

The Winner is the one with the largest number of points.

For [[#Pairwise Election|Pairwise Elections]] plurality is a simple **majority election**.

Anomalies with Plurality:
Let $|Ag|= 100$ and $\Omega = \{ \omega _1, \omega _2, \omega_3 \}$ with:

40% voting for $\omega_1$
30% voting for $\omega_2$
30% voting for $\omega_3$

With plurality $\omega_1$ wins even though a clear majority (30% each voting for $\omega_2$ and $\omega_3$) prefers another winner.
## Preference Aggregation
The process of combining individual [[#Preferences]] from [[#Voters]] into a single decision or outcome.

Two Variants:
- [[#Social Welfare Functions]]
- [[#Social Choice Functions]]

## Preferences
Each [[#Voters|Voter]] has an order or preference over the [[#Candidates]].

Example:
$\Omega = \{Monday, Friday, Sunday\}$ 
If we have an agent $Cenk$ his preference over the [[#Candidates]] can be expressed as following:
$Friday ≻_{Cenk} Sunday ≻_{Cenk} Monday$ 
## Sequential Majority Elections
A variant of [[#Plurality]], in which [[#Candidates]] play in a series of rounds.

Either a linear sequence: [[#Linear Sequential Pairwise Elections]] or a tree (knockout tournament)
## Social Choice Functions
Instead of producing a social preference order like the [[#Social Welfare Functions]], a social choice function selects only **one** of the [[#Candidates]]:
$f: \prod(\Omega) \times ... \times \prod(\Omega) \rightarrow \Omega$   

Example: presidential election
## Social Choice Model
Social Choice: The issue about combining [[#Preferences]] to derive a social outcome

Classic example: voting

In a social choice model a set of [[#Voters]] make a group decisions with reference to a set of [[#Candidates]].
 
Fundamental problem:
How can we combine all [[#Voters]] [[#Preferences]] into a group decision that best reflects the [[#Voters]] collective [[#Preferences]]? 
Two variants of preference aggregation to solve this:

## Social Welfare Functions
A social welfare function take the [[#Preferences]] of the [[#Voters]] and produces a social preference order: 
$f: \prod(\Omega) \times ... \times \prod(\Omega) \rightarrow  \prod(\Omega)$   

Example: beauty contest


## Strategic Manipulation
Voters can benefit by strategically misrepresenting their [[#Preferences]], as seen in [[#Tactical Voting]].

Through [[#The Gibbard-Satterthwaite Theorem]] its known that every "realistic" voting method is prey to strategic manipulation.
## Tactical Voting
When a [[#Voters|voter]] chooses a [[#Candidates|candidate]] not based on their **true [[#Preferences|preference]]**, but to influence the election outcome in their favor. This is a form of [[#Strategic Manipulation]]

Suppose your true preference are:
$\omega_1 ≻ \omega_2 ≻ \omega_3$ 
while you believe that 49% of [[#Voters|voters]] have preferences:
$\omega_2 ≻ \omega_1 ≻ \omega_3$ 
and you believe that 49% of [[#Voters|voters]] have preferences:
$\omega_3 ≻ \omega_2 ≻ \omega_1$ 

By voting for either $\omega_2$ or $\omega_3$ you can alter the result of the vote, even though your true preference is $\omega_1$.

Voting for $\omega_1$:
2%: $\omega_1 ≻ \omega_2 ≻ \omega_3$ 
49%: $\omega_2 ≻ \omega_1 ≻ \omega_3$  $\rightarrow$ No Clear Winner 
49%: $\omega_3 ≻ \omega_2 ≻ \omega_1$ 

Voting for $\omega_2$:
51%: $\omega_2 ≻ \omega_1 ≻ \omega_3$  $\rightarrow$ $\omega_2$ wins   
49%: $\omega_3 ≻ \omega_2 ≻ \omega_1$ 

Voting for $\omega_3$:
49%: $\omega_2 ≻ \omega_1 ≻ \omega_3$  
51%: $\omega_3 ≻ \omega_2 ≻ \omega_1$ $\rightarrow$ $\omega_3$ wins   

## The Gibbard-Satterthwaite Theorem
The Theorem answers the question if there is voting method that are immune to [[#Strategic Manipulation]]. 
The answer given is:
The only non-manipulable voting method satisfying [[#The Pareto Property]] for elections with more than 2 candidates is a dictatorship.

Every "realistic" voting method is prey to strategic manipulation. 





## The Pareto Property
If everybody prefers $\omega_i$ over $\omega_j$, then $\omega_i$ should be ranked over $\omega_j$ in the social outcome.

That means if everyone prefers one option to another, the group decision should reflect that.


## Voters
A set of voters $Ag = \{1,...,n\}$ are entities who will be expressing [[#Preferences]].


