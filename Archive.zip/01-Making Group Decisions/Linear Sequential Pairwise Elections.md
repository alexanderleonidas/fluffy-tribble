A variant of [[Sequential Majority Elections]], in which the [[Candidates]] play in a series of linear rounds:

![[Linear-Sq-Pairwise-Elec.png]]  

There has to be an ordering of the [[candidates]] - the **agenda** - which determines who plays against who.

The agenda seen in the example above is:
$\omega_2, \omega_3, \omega_4, \omega_1$ 

The first election is between $\omega_2$ and $\omega_3$, and the winner($\omega_2$) goes on to an election with $\omega_4$ and the winner of this election($\omega_4$) goes in an election with $\omega_1$. 

It can also be depicted like this:
$\omega_2, \omega_3, \omega_4, \omega_1 \rightarrow \omega_2, \omega_4, \omega_1 \rightarrow \omega_4, \omega_1 \rightarrow \omega_1$ wins

There are also [[Anomalies with Sequential Pairwise Elections|Anomalies with the sequential pairwise elections]], by fixing an agenda that leads a [[Candidates|candidate]] to win.