A direct graph where:
- vertices = [[Candidates]]
- an edge $(i,j)$ if $i$ would beat $j$ in a [[Plurality|simple majority election]].

For the example in [[Anomalies with Sequential Pairwise Elections]] the Majority Graph would look like this:

 ![[Majority-Graph-Example01.png]]

Another example of a majority graph with 4 [[Candidates]]:

![[Majority-Graph-Example02.png]]

In this example the candidates would win with the following [[Linear Sequential Pairwise Elections|agendas]]:
$\omega_4, \omega_2, \omega_3, \omega_1 \rightarrow \omega_1$ wins 
$\omega_4,\omega_3,\omega_1,\omega_2 \rightarrow \omega_2$ wins
$\omega_2,\omega_1,\omega_4,\omega_3 \rightarrow \omega_3$ wins
$\omega_3,\omega_4,\omega_1,\omega_2 \rightarrow \omega_2$ wins
