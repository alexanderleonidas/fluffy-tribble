If there are only two [[Candidates]], we have a pairwise election.
$|\Omega|=2$ -> pairwise election
