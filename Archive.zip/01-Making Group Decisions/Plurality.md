Plurality is a [[Social Choice Functions|social choice function]] and therefore selects a single outcome.

The [[Voters]] submit their [[Preferences]] and each [[Candidates|Candidate]] gets one point for every [[Preferences|preference order]] that ranks them first.

The Winner is the one with the largest number of points.

For [[Pairwise Election|Pairwise Elections]] plurality is a simple **majority election**.

Anomalies with Plurality:
Let $|Ag|= 100$ and $\Omega = \{ \omega _1, \omega _2, \omega_3 \}$ with:

40% voting for $\omega_1$
30% voting for $\omega_2$
30% voting for $\omega_3$

With plurality $\omega_1$ wins even though a clear majority (30% each voting for $\omega_2$ and $\omega_3$) prefers another winner.