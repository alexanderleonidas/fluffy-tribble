The process of combining individual [[Preferences]] from [[Voters]] into a single decision or outcome.

Two Variants:
- [[Social Welfare Functions]]
- [[Social Choice Functions]]
