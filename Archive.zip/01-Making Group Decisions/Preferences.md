Each [[Voters|Voter]] has an order or preference over the [[Candidates]].

Example:
$\Omega = \{Monday, Friday, Sunday\}$ 
If we have an agent $Cenk$ his preference over the [[Candidates]] can be expressed as following:
$Friday ≻_{Cenk} Sunday ≻_{Cenk} Monday$ 