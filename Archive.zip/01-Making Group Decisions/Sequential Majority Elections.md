A variant of [[Plurality]], in which [[Candidates]] play in a series of rounds.

Either a linear sequence: [[Linear Sequential Pairwise Elections]] or a tree (knockout tournament)