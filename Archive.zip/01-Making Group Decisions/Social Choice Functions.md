Instead of producing a social preference order like the [[Social Welfare Functions]], a social choice function selects only **one** of the [[Candidates]]:
$f: \prod(\Omega) \times ... \times \prod(\Omega) \rightarrow \Omega$   

Example: presidential election