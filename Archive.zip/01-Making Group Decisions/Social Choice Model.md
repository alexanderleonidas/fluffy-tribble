Social Choice: The issue about combining [[Preferences]] to derive a social outcome

Classic example: voting

In a social choice model a set of [[Voters]] make a group decisions with reference to a set of [[Candidates]].
 
Fundamental problem:
How can we combine all [[Voters]] [[Preferences]] into a group decision that best reflects the [[Voters]] collective [[Preferences]]? 
Two variants of preference aggregation to solve this:
