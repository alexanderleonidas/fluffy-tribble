A social welfare function take the [[Preferences]] of the [[Voters]] and produces a social preference order: 
$f: \prod(\Omega) \times ... \times \prod(\Omega) \rightarrow  \prod(\Omega)$   

Example: beauty contest

