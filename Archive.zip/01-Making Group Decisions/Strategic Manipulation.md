Voters can benefit by strategically misrepresenting their [[Preferences]], as seen in [[Tactical Voting]].

Through [[The Gibbard-Satterthwaite Theorem]] its known that every "realistic" voting method is prey to strategic manipulation.