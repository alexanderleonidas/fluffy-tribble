When a [[Voters|voter]] chooses a [[Candidates|candidate]] not based on their **true [[Preferences|preference]]**, but to influence the election outcome in their favor. This is a form of [[Strategic Manipulation]]

Suppose your true preference are:
$\omega_1 ≻ \omega_2 ≻ \omega_3$ 
while you believe that 49% of [[Voters|voters]] have preferences:
$\omega_2 ≻ \omega_1 ≻ \omega_3$ 
and you believe that 49% of [[Voters|voters]] have preferences:
$\omega_3 ≻ \omega_2 ≻ \omega_1$ 

By voting for either $\omega_2$ or $\omega_3$ you can alter the result of the vote, even though your true preference is $\omega_1$.

Voting for $\omega_1$:
2%: $\omega_1 ≻ \omega_2 ≻ \omega_3$ 
49%: $\omega_2 ≻ \omega_1 ≻ \omega_3$  $\rightarrow$ No Clear Winner 
49%: $\omega_3 ≻ \omega_2 ≻ \omega_1$ 

Voting for $\omega_2$:
51%: $\omega_2 ≻ \omega_1 ≻ \omega_3$  $\rightarrow$ $\omega_2$ wins   
49%: $\omega_3 ≻ \omega_2 ≻ \omega_1$ 

Voting for $\omega_3$:
49%: $\omega_2 ≻ \omega_1 ≻ \omega_3$  
51%: $\omega_3 ≻ \omega_2 ≻ \omega_1$ $\rightarrow$ $\omega_3$ wins   
