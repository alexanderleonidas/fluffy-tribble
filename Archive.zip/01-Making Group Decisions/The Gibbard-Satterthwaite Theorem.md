The Theorem answers the question if there is voting method that are immune to [[Strategic Manipulation]]. 
The answer given is:
The only non-manipulable voting method satisfying [[The Pareto Property]] for elections with more than 2 candidates is a dictatorship.

Every "realistic" voting method is prey to strategic manipulation. 




