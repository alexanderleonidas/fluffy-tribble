If everybody prefers $\omega_i$ over $\omega_j$, then $\omega_i$ should be ranked over $\omega_j$ in the social outcome.

That means if everyone prefers one option to another, the group decision should reflect that.

