A set of voters $Ag = \{1,...,n\}$ are entities who will be expressing [[Preferences]].
