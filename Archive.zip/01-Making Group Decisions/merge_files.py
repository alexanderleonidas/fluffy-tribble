import os
from pathlib import Path
import re

folder_path = Path.cwd()
exclude_file = 'Lecture 1.md'

# List all .md files in the folder, excluding 'lecture1.md'
md_files = [f for f in os.listdir(folder_path) if f.endswith('.md') and f != exclude_file]

all_files_content = ''
# Print the list of .md files
for md_file in md_files:
    # read the file content
    # if a line starts with a #, add another hastag before it
    # if a line contains [[<link>]] replace it with [[#<link>]]
    # if a line contains ![[<link>]] dont touch the link
    with open(md_file, 'r') as f:
        content = f.readlines()
        all_files_content += f'## {md_file[:-3]}\n'
        for line in content:
            if line.startswith('#'):
                line = '#' + line
            line = re.sub(r'(?<!\!)\[\[([^\]]+)\]\]', r'[[#\1]]', line)
            all_files_content += line

        all_files_content += '\n'

with open(exclude_file, 'w') as f:
    f.write(all_files_content)