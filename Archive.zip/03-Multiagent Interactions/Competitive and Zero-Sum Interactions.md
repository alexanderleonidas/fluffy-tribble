**Strictly competitive** scenarios happen, where preferences of agents are completely opposed.

Competitive interactions occur when agents act in opposition to each other, and gain often comes at the expense of the other(s).


Zero-sum encounters are those where utilities sum to zero:
$u_i(\omega) + u_j(\omega) = 0\quad \forall \omega \in \Omega$

If one agent wants to improve their [[Utility]], it directly worsens the other agents utility.