A strategy $s_i$ is **dominant** for player $i$, if no matter what strategy $s_j$ agent $j$ chooses, agent $i$ will do at least as well playing $s_i$ as it would doing anything else.

Unfortunately, there isn't always a dominant strategy.