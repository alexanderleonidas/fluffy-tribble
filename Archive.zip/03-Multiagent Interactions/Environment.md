The environment is the system or context in which the agents operate.

A model of the environment is necessary to understand and predict how actions by the agents translate into specific [[outcomes]]. 