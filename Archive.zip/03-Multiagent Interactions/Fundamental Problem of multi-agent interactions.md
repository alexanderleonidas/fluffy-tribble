It appears that cooperation will not occur in societies of self-interested agents.

Argument to recover cooperation is [[Program Equilibria]]