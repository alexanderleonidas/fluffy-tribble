Players $i$ and $j$ simultaneously choose the face of a coin.
If they show the same face, then $i$ wins, while if they show different faces, then $j$ wins.

[[Utility Functions]]:

$u_i(H,H)=1 \quad u_i(H,T)=-1 \quad u_i(T,H)=-1 \quad u_i(T,T)=1$
$u_j(H,H)=-1 \quad u_j(H,T)=1 \quad u_j(T,H)=1 \quad u_j(T,T)=-1$

with $\omega_i \in \Omega=\{HH,HT,TH,TT\}$:

$u_i(\omega_1)=1 \quad u_i(\omega_2)=-1 \quad u_i(\omega_3)=-1 \quad u_i(\omega_4)=1$
$u_j(\omega_1)=-1 \quad u_j(\omega_2)=1 \quad u_j(\omega_3)=1 \quad u_j(\omega_4)=-1$


[[Payoff Matrix]]:

![[Payoff-Matrix-Example02.png]]

There is no pair of strategies forms a pure strategy [[Nash Equilibrium|NE]]:
Whatever pair of strategy is chosen, somebody will wish they had done something else.

The Solution is to allow [[mixed strategies]].
