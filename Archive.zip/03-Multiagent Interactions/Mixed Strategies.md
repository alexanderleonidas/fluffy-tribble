The solution of a lack of a pure strategy NE is to allow players to adopt mixed strategies.

A mixed strategy involves randomizing over the available pure strategies with specific probabilities.

It has the form:
- play $\alpha_1$ with probability $p_1$ 
- play $a_2$ with probability $p_2$ 
- ...
- play $a_k$ with probability $p_k$ 
such that $p_1 + p_2 + ... + p_k = 1$ 

Every finite game has a [[Nash Equilibrium|NE]] in mixed strategies, proven in [[Nash's Theorem]]