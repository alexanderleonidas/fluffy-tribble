There needs to be a model of the environment in which these agents will act.

Agents simultaneously choose an action to perform, and as a result of the action they select, an outcome in $\Omega$ will result.

The **actual** [[outcomes|outcome]] depends on the combination of actions.

Assuming each agent has just two possible actions that it can perform:
$C$ ("cooperate") and $D$ ("defect") 

The [[Environment]] behavior is given by state transformer function:
$τ: Ac \times Ac \rightarrow \Omega$ 

If one Agent chooses $C$ and one Agent chooses $D$, the [[outcomes|outcome]] might differ from both, but it will still be an element of $\Omega$, the set of all possible [[outcomes|outcomes]].