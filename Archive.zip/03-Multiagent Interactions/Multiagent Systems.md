A multi-agent system contains a number of agents which:
- interact through communication
- are able to act in an environment
- have different "spheres of influence"
- will be linked by other (organisational) relationships