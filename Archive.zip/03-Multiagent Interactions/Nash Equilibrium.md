Two strategies $s_1$ and $s_2$ are in Nash equilibrium if:
1. Under the assumption that agent $i$ plays $s_1$, agent $j$ can do not better than play $s_2$; and
2. under the assumption that agent $j$ plays $s_2$, agent $i$ can do no better than play $s_1$ 

Neither agent has any incentive to deviate from a Nash equilibrium.

But, unfortunately:
Not every interaction scenario has a Nash Equilibrium.
Some interaction scenarios have more than one Nash equilibrium.