An Environment consists of different possible outcomes, represented by the set:  $\Omega=\{ \omega _1, \omega _2, ... \}$.
These outcomes are different scenarios that an agent is concerned with and over which they have a [[Preferences|preferance]].
