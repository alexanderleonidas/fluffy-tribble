An [[outcomes]] is said to be Pareto optimal (or Pareto efficient) if there is no other outcome that makes one agent better off without making another agent worse off.

Pareto optimal = impossible to make on agent better off without making at least on other worse off.

Therefore no further improvements can be made that benefits an agent without harming another.

This also means that, if an outcome $\omega$ is **not** Pareto optimal, then there exists another outcome $\omega'$, that makes everyone as happy if not even happier, than $\omega$. 

"Reasonable" agents would move to $\omega'$ in that case.

