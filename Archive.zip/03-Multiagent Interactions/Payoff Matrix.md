The payoff matrix summarizes the [[Utility]] for agents based on their chosen action.

![[Payoff-Matrix-Example01.png]]

The scenario in [[Rational Action]] is shown above.
Agent $i$ is the column player. 
Agent $j$ is the row player.


