The utility function allows us to define a **preference ordering** for each agent over the [[Outcomes|outcomes]].

This ordering reflects how an agent ranks the outcomes according to their [[utility]].

$\omega ⪰_i \omega'$ means that agent $i$ prefers [[outcomes|outcome]] $\omega$ over $\omega'$, or is indifferent between them.

In Terms of [[utility]] this means $u_i(\omega)  ≥ u_i(\omega')$, which indicates that the utility of outcome $\omega$ is at least as large as that of outcome $\omega'$.











