Scenario:
Two men are collectively charged with a crime and held in separate cells, with no way of communicating.

They are told that:
- If one confessed and the other does not, the confessor will be freed, and the other will be jailed for three years;
- if both confess then each will be jailed for two years
If both prisoners neither confessed then they will each be jailed for one year.

With $\omega_i \in \Omega=\{DD,DC,CD,CC\}$
$D$ ("defect") and $C$ ("coop")

[[Payoff Matrix]]:
![[Payoff-Matrix-Example03.png]]

Top left: both snitched and get punished
Top right: $i$ cooperates and $j$ defects, ends up in $i$ payoff of 1, while $j$ gets 4.
Bottom left: $j$ cooperates and $i$ defects, ends up in $i$ payoff of 1, while $i$ gets 4.
Bottom right: both get rewarded for not snitching

What to do:
individual rational action is defect, guarantees payoff of no worse than 2, whereas cooperating guarantees a payoff of at most 1.

[[Solution Concepts]]:
- $D$ is a [[Dominant Strategy]]
- $(D,D)$ is the only [[Nash Equilibrium]]
- All outcomes except $(D,D)$ are [[Pareto Optimality|Pareto Optimal]]
- $(C,C)$ maximizes [[Social Welfare]]

Even though $(C,C)$ would maximize social welfare, $D$ is the way to go, because of the [[Fundamental Problem of multi-agent interactions]].

This dilemma is ubiquitous. 

