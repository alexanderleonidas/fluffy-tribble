Each agent submits a program strategy to a mediator which jointly executes the strategies.

Important to understand that strategies can be conditioned on the strategies of the others.

```
IF HisProgram == ThisProgram THEN
    DO(C);
ELSE
	DO (D);
END-IF.
```

Best option to this programm is to submit the same program, giving an outcome of $(C,C)$
