Suppose both agents can influence the outcome, will following [[Utility Functions]]:

$u_i(\omega_1) = 1\quad$ $u_i(\omega_2)=1\quad$ $u_i(\omega_3)=4\quad$  $u_i(\omega_4)=4$ 

$u_j(\omega_1) = 1\quad$ $u_j(\omega_2)=4\quad$ $u_j(\omega_3)=1\quad$  $u_j(\omega_4)=4$ 

Because $w_i$ is an outcome, we can also use the following notation:

$u_i(D,D) = 1\quad$ $u_i(D,C)=1\quad$ $u_i(C,D)=4\quad$  $u_i(C,C)=4$ 

$u_j(D,D) = 1\quad$ $u_j(D,C)=4\quad$ $u_j(C,D)=1\quad$  $u_j(C,C)=4$ 

Therefore agents $i$'s preferences are:

$C,C ⪰_i C,D \quad ⪰_i \quad D,C ⪰_i D,D$ 

$C$ is the **rational choice** for $i$, because $i$ prefers all outcomes that arise through $C$ over all outcomes that arise through $D$.

This concept can also be characterized in a [[Payoff Matrix]]
