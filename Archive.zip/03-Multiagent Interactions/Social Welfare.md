The social welfare of an [[outcomes]] $\omega$ is the sum of the [[Utility|utilities]] that each agent gets from $\omega$:

$\sum_{i \in Ag}u_i(\omega)$ 
$Ag$ is the set of all agents in the system
$u_i(\omega)$ represents the [[utility]] that agent $i$ derives from [[Outcomes|outcome]] $\omega$.

This concept makes sense when the entire system operates under a single decision-maker or owner:
- Focus on overall benefit of the system rather then well-being or preferences of individual agents
