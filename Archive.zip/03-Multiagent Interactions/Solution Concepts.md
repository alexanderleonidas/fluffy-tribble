Solution Concepts answer the question how a [[Rational Action|rational agent]] will behave in any given scenario.

The Solution concepts are the following:
- [[Dominant Strategy]]
- [[Nash Equilibrium]]
- [[Pareto Optimality]]
- [[Social Welfare]]
