A state transformer function maps actions chosen by agents to a specific [[Outcomes|outcome]] in $\Omega$.

The [[Environment]] behavior is given by state transformer function:
$τ: Ac \times Ac \rightarrow \Omega$ 

Examples:

$τ(D,D) = \omega_1$, $τ(D,C) = \omega_2$, $τ(C,D) = \omega_3$, $τ(C,C) = \omega_4$
This environment is sensitive to actions of both agents.

$τ(D,D) = \omega_1$, $τ(D,C) = \omega_1$, $τ(C,D) = \omega_1$, $τ(C,C) = \omega_1$
Neither agent has any influence in this environment.

$τ(D,D) = \omega_1$, $τ(D,C) = \omega_2$, $τ(C,D) = \omega_1$, $τ(C,C) = \omega_2$
This environment is controlled by the second agent.

