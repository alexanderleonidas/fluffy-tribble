Assume we have just two agents: $Ag=\{i,j\}$ 

Agents are assumed to be **self-interested**, meaning they have preferences over how the environment is.

Therefore each Agent makes decisions based on their own preferences

Assume $\Omega = \{\omega_1, \omega_2,...\}$ are the [[Outcomes|outcomes]] that agents have a [[Preferences|preference]] over.

Those Preferences are captured by [[utility functions]]:
$u_i:\Omega \rightarrow \mathbb{R}$
$u_j:\Omega \rightarrow \mathbb{R}$ 

[[Utility functions]] lead to [[Preference Ordering]] over outcomes:
$\omega ⪰_i \omega'$ means $u_i(\omega)  ≥ u_i(\omega')$
$\omega ≻_i \omega'$ means $u_i(\omega)  > u_i(\omega')$