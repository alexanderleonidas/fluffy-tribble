We capture Preferences by Utility Functions:
$u_i:\Omega \rightarrow \mathbb{R}$
$u_j:\Omega \rightarrow \mathbb{R}$ 

A utility function $u_i:Ω→R$ for agent $i$ maps each [[outcomes|outcome]] $\omega \in \Omega$ to a real number, representing the state of satisfaction or utility the agent derives from that outcome.

Similarly agent $j$ has a Utility Function $u_j:Ω→R$, which works the same way but for agent $j$.  